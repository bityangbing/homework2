clear all;
clear all;

[data, text] =  xlsread(['diagnosis.xls']);
[m, n] = size(text);

andata = zeros(m, n);
for i=1:1:m
    temp = text{i,:};
    temp = strrep(temp,',','.');
    temp = str2num(temp);   
    andata(i,1) = temp;
end

for i=2:1:m
    for j=1:1:n       
        temp = text{i,j};        
        if(strcmp(temp,'yes'))
            andata(i,j) = 1;           
        end        
    end
end


%% �����¶ȣ���38����Ϊ�ٽ��
tem1 = zeros(m, 1);
tem2 = zeros(m, 1);
for i=1:1:m   
    if(andata(i,1)<=38)       
        tem1(i,1) = 1;       %С�ڵ���38
    else        
        tem2(i,1) = 1;        
    end    
end

analysisdata = zeros(m, n+1);
analysisdata(:,1) = tem1;
analysisdata(:,2) = tem2;
analysisdata(1:m,3:n+1) = andata(1:m,2:n);
save('data.mat','analysisdata');





