function [c]=setsub(a,b)
%������� a-b=c
l1=length(a);
l2=length(b);
k=0;
for i=1:l1
    r=0;
    for j=1:l2
        if a(i)==b(j)
           r=1;   
        end
    end
    if r==0
        k=k+1;
        c(k)=a(i);
    end
end